package com.example.watermelon.game

import android.content.Context
import android.graphics.Canvas
import android.view.SurfaceHolder
import android.view.SurfaceView

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    private val gameThread: GameThread
    private val fruitManager: FruitManager
    private var containerLeft: Float = 0f
    private var containerRight: Float = 0f
    private var containerBottom: Float = 0f

    init {
        holder.addCallback(this)
        gameThread = GameThread(holder, this)
        fruitManager = FruitManager(context)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        // Initialize the container size here
        containerLeft = 0f
        containerRight = width.toFloat()
        containerBottom = height.toFloat()




        gameThread.setRunning(true)
        gameThread.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        // Handle surface changes if needed
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true
        while (retry) {
            try {
                gameThread.setRunning(false)
                gameThread.join()
            } catch (e: InterruptedException) {
                e.printStackTrace()
                retry = false
            }
        }
    }

    fun update() {
        fruitManager.update(containerLeft, containerRight, containerBottom)
        fruitManager.combineFruits()  // Add this to handle fruit combining logic
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        fruitManager.draw(canvas)
    }
}
