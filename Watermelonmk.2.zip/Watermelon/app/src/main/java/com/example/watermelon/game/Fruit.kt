package com.example.watermelon.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import androidx.annotation.DrawableRes
import com.example.watermelon.R

enum class FruitType(@DrawableRes val drawableRes: Int, val sizeRatio: Float, val weight: Float) {
    CHERRY(R.drawable.cherry, 0.05f, 1f),
    GRAPE(R.drawable.grape, 0.07f, 1.2f),
    STRAW(R.drawable.straw, 0.09f, 1.5f),
    KIWI(R.drawable.kiwi, 0.11f, 1.8f),
    ORANGE(R.drawable.orange, 0.13f, 2.1f),
    APPLE(R.drawable.apple, 0.15f, 2.5f),
    PEACH(R.drawable.peach, 0.17f, 3f),
    MG(R.drawable.mg, 0.19f, 3.5f),
    DF(R.drawable.df, 0.20f, 4f),
    WATERMELON(R.drawable.watermelon, 0.35f, 5f)
}

class Fruit(private val context: Context, var x: Float, var y: Float, var type: FruitType) {
    var size: Float = type.sizeRatio * context.resources.displayMetrics.widthPixels
    private var bitmap: Bitmap = BitmapFactory.decodeResource(context.resources, type.drawableRes)
    private var speed: Float = 5f
    private val gravity: Float = 10f
    var isMerged: Boolean = false  // Prevents duplicate merging

    fun getRadius(): Float {
        return size / 2
    }

    // Add collision detection logic
    fun isCollidingWith(other: Fruit): Boolean {
        val dx = this.x - other.x
        val dy = this.y - other.y
        val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        return distance < (this.getRadius() + other.getRadius())
    }

    fun update(containerLeft: Float, containerRight: Float, containerBottom: Float, fruits: MutableList<Fruit>) {
        // Apply gravity
        if (y + size / 2 < containerBottom) {
            speed += gravity
            y += speed
        } else {
            y = containerBottom - size / 2
            speed = 0f
        }

        // Keep inside container
        if (x - size / 2 < containerLeft) x = containerLeft + size / 2
        if (x + size / 2 > containerRight) x = containerRight - size / 2

        // Check for collisions and stacking
        for (other in fruits) {
            if (this !== other && isCollidingWith(other)) {
                // If the fruits are different types, prevent further downward movement and stack them
                if (this.type != other.type) {
                    val overlap = (this.getRadius() + other.getRadius()) - distanceBetween(this, other)
                    if (overlap > 0) {
                        y = other.y - size / 2 - overlap  // Adjust y-position to stack the fruit
                        speed = 0f  // Stop downward movement
                        break  // Stop checking further collisions, as we've stacked it
                    }
                }
            }
        }
    }

    fun distanceBetween(fruit1: Fruit, fruit2: Fruit): Float {
        val dx = fruit1.x - fruit2.x
        val dy = fruit1.y - fruit2.y
        return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    // Combine fruits into the next fruit type
    fun combineWith(other: Fruit): FruitType? {
        // Check if the two fruits are of the same type
        if (this.type == other.type) {
            val nextIndex = FruitType.values().indexOf(this.type) + 1
            if (nextIndex < FruitType.values().size) {
                return FruitType.values()[nextIndex]  // Return the next tier fruit
            }
        }
        return null  // Return null if not the same type
    }

    // Add the draw method here
    fun draw(canvas: Canvas) {
        canvas.drawBitmap(bitmap, x - size / 2, y - size / 2, null)
    }
}
