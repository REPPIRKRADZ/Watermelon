package com.example.watermelon.game

import android.graphics.Bitmap
import android.graphics.Color

fun Bitmap.removeTransparentBorder(): Bitmap {
    val width = this.width
    val height = this.height
    var minX = width
    var minY = height
    var maxX = 0
    var maxY = 0

    // Scan pixels to find the actual fruit area (ignoring transparent areas)
    for (y in 0 until height) {
        for (x in 0 until width) {
            val pixel = this.getPixel(x, y)
            if (Color.alpha(pixel) > 10) { // Ignore fully transparent pixels
                if (x < minX) minX = x
                if (y < minY) minY = y
                if (x > maxX) maxX = x
                if (y > maxY) maxY = y
            }
        }
    }

    return if (minX < maxX && minY < maxY) {
        Bitmap.createBitmap(this, minX, minY, maxX - minX + 1, maxY - minY + 1)
    } else {
        this // Return original if no valid crop found
    }
}
