package com.example.watermelon.game

import android.content.Context
import android.graphics.Canvas

class FruitManager(private val context: Context) {
    private val fruits = mutableListOf<Fruit>()

    // Add fruit to the game
    fun addFruit(x: Float, y: Float, type: FruitType) {
        fruits.add(Fruit(context, x, y, type))
    }

    // Update all fruits in the game
    fun update(containerLeft: Float, containerRight: Float, containerBottom: Float) {
        for (fruit in fruits) {
            fruit.update(containerLeft, containerRight, containerBottom, fruits)
        }
    }

    // Combine matching fruits into new fruit type
    fun combineFruits() {
        val fruitsToRemove = mutableListOf<Fruit>()
        val fruitsToAdd = mutableListOf<Fruit>()

        for (i in fruits.indices) {
            for (j in i + 1 until fruits.size) {
                val fruit1 = fruits[i]
                val fruit2 = fruits[j]
                // If two fruits collide and can be combined
                if (fruit1.isCollidingWith(fruit2) && fruit1.type == fruit2.type && !fruit1.isMerged && !fruit2.isMerged) {
                    val newType = fruit1.combineWith(fruit2)
                    if (newType != null) {
                        // Create a new fruit of the combined type
                        val newFruit = Fruit(context, (fruit1.x + fruit2.x) / 2, (fruit1.y + fruit2.y) / 2, newType)
                        fruitsToRemove.add(fruit1)
                        fruitsToRemove.add(fruit2)
                        fruitsToAdd.add(newFruit)

                        // Mark original fruits as merged to avoid duplication
                        fruit1.isMerged = true
                        fruit2.isMerged = true
                    }
                }
            }
        }

        // Remove the merged fruits and add new merged fruit
        fruits.removeAll(fruitsToRemove)
        fruits.addAll(fruitsToAdd)
    }

    // Draw all the fruits on the canvas
    fun draw(canvas: Canvas) {
        for (fruit in fruits) {
            fruit.draw(canvas)
        }
    }
}
