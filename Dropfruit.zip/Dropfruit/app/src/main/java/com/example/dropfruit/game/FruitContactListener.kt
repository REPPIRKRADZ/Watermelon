package com.example.dropfruit.game

import org.jbox2d.callbacks.ContactImpulse
import org.jbox2d.callbacks.ContactListener
import org.jbox2d.collision.Manifold
import org.jbox2d.dynamics.Body
import org.jbox2d.dynamics.contacts.Contact

class FruitContactListener(
    private val onMerge: (Body, Body) -> Unit
) : ContactListener {
    override fun beginContact(contact: Contact) {

        val bodyA = contact.fixtureA.body
        val bodyB = contact.fixtureB.body

        val fruitA = bodyA.userData as? Fruit
        val fruitB = bodyB.userData as? Fruit

        if (fruitA != null && fruitB != null && fruitA.id == fruitB.id) {
            onMerge(bodyA, bodyB)
        }
        println("Collision detected: ${fruitA?.id} vs ${fruitB?.id}")

    }

    override fun endContact(contact: Contact) {}
    override fun preSolve(contact: Contact, oldManifold: Manifold) {}
    override fun postSolve(contact: Contact, impulse: ContactImpulse) {}
}
