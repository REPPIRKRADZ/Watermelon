package com.example.dropfruit.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import com.example.dropfruit.R
import kotlinx.coroutines.delay
import org.jbox2d.collision.shapes.CircleShape
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.*

@Composable
fun GameScreen() {
    val physicsWorld = remember { PhysicsWorld() }
    val world = physicsWorld.world

    val containerWidth = 0.8f
    val containerHeight = 0.7f
    val startX = (1 - containerWidth) / 2
    val startY = 0.25f

    var currentFruit by remember { mutableStateOf(FruitManager.getNextFruit()) }
    val nextFruit = remember { mutableStateOf(FruitManager.peekNextFruit()) }

    var fruitX by remember { mutableStateOf(startX + containerWidth / 2) }
    var isDragging by remember { mutableStateOf(false) }
    val fruits = remember { mutableStateListOf<Pair<Fruit, Body>>() }

    val bodiesToRemove = mutableListOf<Body>() // Queue for removal
    val postPhysicsActions = mutableListOf<() -> Unit>() // Queue for delayed tasks

    LaunchedEffect(Unit) {
        createBorder(world, startX, startY, containerWidth, containerHeight)
        while (true) {
            world.step(1 / 60f, 6, 2)
            removeBodiesAfterStep(world, bodiesToRemove)

            // Execute delayed actions safely
            postPhysicsActions.forEach { it() }
            postPhysicsActions.clear()

            delay(16L)
        }
    }

    fun dropFruit() {
        val bodyDef = BodyDef().apply {
            type = BodyType.DYNAMIC
            position.set(fruitX, startY)
        }
        val body = world.createBody(bodyDef)

        val shape = CircleShape().apply {
            radius = currentFruit.radius
        }
        val fixtureDef = FixtureDef().apply {
            this.shape = shape
            density = 1f
            friction = 0.3f
            restitution = 0.5f
        }
        body.createFixture(fixtureDef)
        body.userData = currentFruit
        fruits.add(currentFruit to body)

        currentFruit = FruitManager.getNextFruit()
        nextFruit.value = FruitManager.peekNextFruit()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        fruitX = (fruitX + dragAmount.x / 1000f).coerceIn(startX, startX + containerWidth)
                    },
                    onDragEnd = {
                        isDragging = false
                        dropFruit()
                    }
                )
            }
    ) {
        Image(
            painter = painterResource(id = R.drawable.blue),
            contentDescription = "Game Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        if (isDragging) {
            Image(
                painter = painterResource(id = currentFruit.id),
                contentDescription = "Current Fruit",
                modifier = Modifier
                    .offset(x = (fruitX * 300).dp, y = (startY * 400).dp)
                    .size((currentFruit.radius * 1000 * containerWidth).dp)
            )
        }

        nextFruit.value?.let { next ->
            Image(
                painter = painterResource(id = next.id),
                contentDescription = "Next Fruit",
                modifier = Modifier
                    .offset(x = 320.dp, y = 60.dp)
                    .size(65.dp)
            )
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val screenWidth = size.width
            val screenHeight = size.height
            val borderLeft = screenWidth * startX
            val borderRight = borderLeft + (screenWidth * containerWidth)
            val borderTop = screenHeight * startY
            val borderBottom = borderTop + (screenHeight * containerHeight)

            drawLine(Color.Black, Offset(borderLeft, borderTop), Offset(borderLeft, borderBottom), strokeWidth = 8f)
            drawLine(Color.Black, Offset(borderRight, borderTop), Offset(borderRight, borderBottom), strokeWidth = 8f)
            drawLine(Color.Black, Offset(borderLeft, borderBottom), Offset(borderRight, borderBottom), strokeWidth = 20f)
        }

        fruits.forEach { (fruit, body) ->
            val position = body.position
            Image(
                painter = painterResource(id = fruit.id),
                contentDescription = "Dropped Fruit",
                modifier = Modifier
                    .offset(x = (position.x * 300).dp, y = (position.y * 400).dp)
                    .size((fruit.radius * 1000 * containerWidth).dp)
            )
        }
    }
}

fun createBorder(world: World, startX: Float, startY: Float, width: Float, height: Float) {
    val bodyDef = BodyDef().apply { type = BodyType.STATIC }

    val borderThickness = 0.005f
    val borderHeight = height / 2 + 5f

    bodyDef.position.set(startX - borderThickness, startY + height / 2)
    val leftBorder = world.createBody(bodyDef)
    val leftShape = org.jbox2d.collision.shapes.PolygonShape().apply { setAsBox(borderThickness, borderHeight) }
    leftBorder.createFixture(leftShape, 0f)

    bodyDef.position.set(startX + width + 0.3f, startY + height / 2)
    val rightBorder = world.createBody(bodyDef)
    val rightShape = org.jbox2d.collision.shapes.PolygonShape().apply { setAsBox(borderThickness, height / 2+5f) }
    rightBorder.createFixture(rightShape, 0f)

    bodyDef.position.set(startX + width / 2, startY + height + 1.17f)
    val bottomBorder = world.createBody(bodyDef)
    val bottomShape = org.jbox2d.collision.shapes.PolygonShape().apply { setAsBox(width / 2 + 5f, 0.005f) }
    bottomBorder.createFixture(bottomShape, 0f)
}

fun mergeFruits(world: World, bodyA: Body, bodyB: Body, postPhysicsActions: MutableList<() -> Unit>, bodiesToRemove: MutableList<Body>) {
    val fruitA = bodyA.userData as? Fruit
    val fruitB = bodyB.userData as? Fruit

    if (fruitA == null || fruitB == null || fruitA.id != fruitB.id) return

    val index = FruitManager.orderedFruits.indexOf(fruitA.id)
    if (index == -1 || index >= FruitManager.orderedFruits.lastIndex) return

    val newFruit = FruitManager.getFruitByIndex(index + 1)
    val newPosition = Vec2(
        (bodyA.position.x + bodyB.position.x) / 2,
        (bodyA.position.y + bodyB.position.y) / 2
    )

    bodiesToRemove.add(bodyA)
    bodiesToRemove.add(bodyB)

    postPhysicsActions.add {
        val newBodyDef = BodyDef().apply {
            type = BodyType.DYNAMIC
            position.set(newPosition)
        }
        val newBody = world.createBody(newBodyDef)

        val shape = CircleShape().apply { radius = newFruit.radius }
        val fixtureDef = FixtureDef().apply {
            this.shape = shape
            density = 1f
            friction = 0.3f
            restitution = 0.3f
        }
        newBody.createFixture(fixtureDef)
        newBody.userData = newFruit
    }
}

fun removeBodiesAfterStep(world: World, bodiesToRemove: MutableList<Body>) {
    bodiesToRemove.forEach { body -> world.destroyBody(body) }
    bodiesToRemove.clear()
}
