package com.example.dropfruit.game

import org.jbox2d.collision.shapes.CircleShape
import org.jbox2d.collision.shapes.PolygonShape
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.*

class PhysicsWorld {
    val world = World(Vec2(0f, 9.8f)) // Gravity applied downwards
    private val postPhysicsActions = mutableListOf<() -> Unit>() // Safe physics updates queue
    private val bodiesToRemove = mutableListOf<Body>() // Track bodies to remove

    init {
        createBorders()
        world.setContactListener(FruitContactListener { bodyA, bodyB ->
            mergeFruits(bodyA, bodyB) // ✅ Fixed function call (no need to pass `world`)
        })
    }

    private fun createBorders() {
        val groundBodyDef = BodyDef()
        val groundBody = world.createBody(groundBodyDef)

        val shape = PolygonShape()
        val fixtureDef = FixtureDef().apply {
            this.shape = shape
            density = 0f
            friction = 0.5f
            restitution = 0.3f // Slight bounce
        }

        // Define boundary dimensions
        val containerWidth = 2.4f
        val containerHeight = 4.0f
        val thickness = 0.2f

        // Bottom boundary
        shape.setAsBox(containerWidth / 2, thickness, Vec2(0f, -containerHeight / 2), 0f)
        groundBody.createFixture(fixtureDef)

        // Left boundary
        shape.setAsBox(thickness, containerHeight / 2, Vec2(-containerWidth / 2, 0f), 0f)
        groundBody.createFixture(fixtureDef)

        // Right boundary
        shape.setAsBox(thickness, containerHeight / 2, Vec2(containerWidth / 2, 0f), 0f)
        groundBody.createFixture(fixtureDef)
    }

    fun step() {
        world.step(1 / 60f, 6, 2)
        removeBodiesAfterStep()
        executePostPhysicsActions()
    }

    private fun mergeFruits(bodyA: Body, bodyB: Body) {
        val fruitA = bodyA.userData as? Fruit
        val fruitB = bodyB.userData as? Fruit

        if (fruitA == null || fruitB == null || fruitA.id != fruitB.id) return

        val nextFruitId = FruitManager.fruitUpgradeMap[fruitA.id] ?: return // Ensure valid upgrade

        val index = FruitManager.orderedFruits.indexOf(fruitA.id)
        if (index == -1 || index >= FruitManager.orderedFruits.lastIndex) return

        val newFruit = FruitManager.getFruitByIndex(index + 1) // Get next upgraded fruit
        val newPosition = Vec2(
            (bodyA.position.x + bodyB.position.x) / 2,
            (bodyA.position.y + bodyB.position.y) / 2
        )

        bodiesToRemove.add(bodyA)
        bodiesToRemove.add(bodyB)

        postPhysicsActions.add {
            val newBodyDef = BodyDef().apply {
                type = BodyType.DYNAMIC
                position.set(newPosition)
            }
            val newBody = world.createBody(newBodyDef)

            val shape = CircleShape().apply { radius = newFruit.radius }
            val fixtureDef = FixtureDef().apply {
                this.shape = shape
                density = 1f
                friction = 0.3f
                restitution = 0.3f
            }
            newBody.createFixture(fixtureDef)
            newBody.userData = newFruit
        }
    }


    private fun removeBodiesAfterStep() {
        bodiesToRemove.forEach { body -> world.destroyBody(body) }
        bodiesToRemove.clear()
    }

    private fun executePostPhysicsActions() {
        postPhysicsActions.forEach { it() }
        postPhysicsActions.clear()
    }
}
