package com.example.dropfruit.game

import org.jbox2d.dynamics.Body

data class Fruit(
    val id: Int,
    val x: Float,
    val y: Float,
    val radius: Float, // Add radius for correct physics size
    var body: Body? = null // Attach Box2D body reference
)
