package com.example.dropfruit.game

import com.example.dropfruit.R

object FruitManager {
    val orderedFruits = listOf(
        R.drawable.cherry,
        R.drawable.grape,
        R.drawable.straw,
        R.drawable.kiwi,
        R.drawable.orange,
        R.drawable.apple,
        R.drawable.peach,
        R.drawable.mg,
        R.drawable.df,
        R.drawable.watermelon
    )

    val orderedSizes = listOf(
        0.05f, 0.06f, 0.08f, 0.1f, 0.12f, 0.14f, 0.16f, 0.18f, 0.2f, 0.24f
    )

    // ✅ Upgrade mapping for merging fruits
    val fruitUpgradeMap = orderedFruits.associateWith { fruitId ->
        val index = orderedFruits.indexOf(fruitId)
        if (index < orderedFruits.lastIndex) orderedFruits[index + 1] else null

    }



    private val availablePoolIndices = listOf(0, 1, 2, 3) // Cherry, Grape, Straw, Kiwi
    private var fruitPool = mutableListOf<Fruit>()

    init {
        resetFruitPool()
    }

    private fun resetFruitPool() {
        fruitPool.clear()
        fruitPool.add(getFruitByIndex(0)) // Always Cherry first

        repeat(3) {
            val randomIndex = availablePoolIndices.random()
            fruitPool.add(getFruitByIndex(randomIndex))
        }
    }

    fun getNextFruit(): Fruit {
        if (fruitPool.isEmpty()) resetFruitPool()
        val fruit = fruitPool.removeAt(0)

        val randomIndex = availablePoolIndices.random()
        fruitPool.add(getFruitByIndex(randomIndex))

        return fruit
    }

    fun peekNextFruit(): Fruit? = fruitPool.getOrNull(0)

    fun getFruitByIndex(index: Int): Fruit {
        println("Creating fruit: id=${orderedFruits[index]}, index=$index")


        if (index !in orderedFruits.indices) {
            throw IllegalArgumentException("Invalid fruit index: $index")
        }
        return Fruit(
            id = orderedFruits[index],
            x = 3f,
            y = 2f,
            radius = orderedSizes[index]

        )

    }

}
